using System;

namespace FigurasCalculadora
{
    abstract class Figura
    {
        public abstract double CalcularArea();
        public abstract double CalcularPerimetro();
    }

    class Triangulo : Figura
    {
        private double Base;
        private double Altura;
        private double Lado1, Lado2, Lado3;

        public Triangulo(double Base, double Altura, double Lado1, double Lado2, double Lado3)
        {
            this.Base = Base;
            this.Altura = Altura;
            this.Lado1 = Lado1;
            this.Lado2 = Lado2;
            this.Lado3 = Lado3;
        }

        public override double CalcularArea()
        {
            return (Base * Altura) / 2;
        }

        public override double CalcularPerimetro()
        {
            return Lado1 + Lado2 + Lado3;
        }
    }

    class Rectangulo : Figura
    {
        private double Largo;
        private double Ancho;

        public Rectangulo(double Largo, double Ancho)
        {
            this.Largo = Largo;
            this.Ancho = Ancho;
        }

        public override double CalcularArea()
        {
            return Largo * Ancho;
        }

        public override double CalcularPerimetro()
        {
            return 2 * (Largo + Ancho);
        }
    }

    class Cuadrado : Figura
    {
        private double Lado;

        public Cuadrado(double Lado)
        {
            this.Lado = Lado;
        }

        public override double CalcularArea()
        {
            return Lado * Lado;
        }

        public override double CalcularPerimetro()
        {
            return 4 * Lado;
        }
    }

    class Circulo : Figura
    {
        private double Radio;

        public Circulo(double Radio)
        {
            this.Radio = Radio;
        }

        public override double CalcularArea()
        {
            return Math.PI * Radio * Radio;
        }

        public override double CalcularPerimetro()
        {
            return 2 * Math.PI * Radio;
        }
    }
}
