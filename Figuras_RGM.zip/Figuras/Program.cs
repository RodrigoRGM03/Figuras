﻿using System;

namespace FigurasCalculadora
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Escoge la figura que deseas calcular:");
            Console.WriteLine("1. Triángulo");
            Console.WriteLine("2. Rectángulo");
            Console.WriteLine("3. Cuadrado");
            Console.WriteLine("4. Círculo");

            int opcion = int.Parse(Console.ReadLine());

            Figura figura = null;

            switch (opcion)
            {
                case 1: // Triángulo
                    Console.Write("Ingresa la base: ");
                    double baseTri = double.Parse(Console.ReadLine());
                    Console.Write("Ingresa la altura: ");
                    double alturaTri = double.Parse(Console.ReadLine());
                    Console.Write("Ingresa el lado 1: ");
                    double lado1 = double.Parse(Console.ReadLine());
                    Console.Write("Ingresa el lado 2: ");
                    double lado2 = double.Parse(Console.ReadLine());
                    Console.Write("Ingresa el lado 3: ");
                    double lado3 = double.Parse(Console.ReadLine());
                    figura = new Triangulo(baseTri, alturaTri, lado1, lado2, lado3);
                    break;

                case 2: // Rectángulo
                    Console.Write("Ingresa el largo: ");
                    double largoRec = double.Parse(Console.ReadLine());
                    Console.Write("Ingresa el ancho: ");
                    double anchoRec = double.Parse(Console.ReadLine());
                    figura = new Rectangulo(largoRec, anchoRec);
                    break;

                case 3: // Cuadrado
                    Console.Write("Ingresa el lado: ");
                    double ladoCua = double.Parse(Console.ReadLine());
                    figura = new Cuadrado(ladoCua);
                    break;

                case 4: // Círculo
                    Console.Write("Ingresa el radio: ");
                    double radioCir = double.Parse(Console.ReadLine());
                    figura = new Circulo(radioCir);
                    break;

                default:
                    Console.WriteLine("Opción no válida.");
                    return;
            }

            Console.WriteLine($"Área: {figura.CalcularArea()}");
            Console.WriteLine($"Perímetro: {figura.CalcularPerimetro()}");
        }
    }
}
